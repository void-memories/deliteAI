from nimbleedge import nimblenet as nm
from moduleA import getA as ga
model = nm.Model("add_model")

A = 20

def add(input):
    model_output = model.run(input['num'])
    return {'output': model_output[0]}

def run(input):
    return {"moduleA_A": ga(), "main_A": A}
