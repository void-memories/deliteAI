A = 10

def getA():
    return A
