from module1 import get_A as ga

A = 3

def run(inputs):
    return {
        "main_A": A,
        "module1_A": ga(),
    }