from module1 import get_A as ga, hello1

A = 3

def run(inputs):
    ga()
    return {
        "main_A": A,
        "module1_A": ga()
    }
