A = 4

def get_A():
    return A
